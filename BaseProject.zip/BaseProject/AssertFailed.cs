﻿
namespace BaseProject
{
    public class AssertFailed
    {
        public readonly string message;

        public AssertFailed(string message)
        {
            this.message = message;
        }
    }
}

